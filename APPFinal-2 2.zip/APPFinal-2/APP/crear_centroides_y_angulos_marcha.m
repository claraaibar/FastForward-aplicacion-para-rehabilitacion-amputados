function [BW,BW_roja_3,BW_verde_3,BW_azul_3_entera,BW_amarilla_3,BW_amarilla_arriba_3_entera,centroids,angulo_cadera,angulo_tobillo,angulo_rodilla] = crear_centroides_y_angulos_marcha(imagen)


[BW_roja_1] = mascara_roja_marcha(imagen);
%imshow(BWr_83);

BW_roja_2 = bwareaopen(BW_roja_1,30);
%imshow(BWr2_83);

se = strel('disk',30);
BW_roja_3 = imclose(BW_roja_2,se);


 s_r  = regionprops(BW_roja_3, 'centroid');
 centroids = cat(1, s_r.Centroid);

  imagen_negra = BW_roja_3;
%Crear imagen en negro
for i = 1:numel(imagen_negra)
    if imagen_negra(i) == 1
imagen_negra(i) = 0;

    end
end



[BW_verde_1] = MARCHA_HSV_VERDE_2(imagen);
% [BW_verde_1] = MARCHA_VERDE_LAB(imagen);
%[BW_verde_1] = mascara_marcha_verde_YY(imagen);
% [BW_verde_1] = mascara_verde_marcha(imagen);
%imshow(BWr_83);
%En este caso no estamos detectando estructuras del fondo, pero si pasa
%tenemos que ajustar este número de píxeles
BW_verde_2 = bwareaopen(BW_verde_1,30);
%imshow(BWr2_83);
BW_verde_3 = imclose(BW_verde_2,se);

 s_v  = regionprops(BW_verde_3, 'centroid');
          centroids(length(centroids),:) = cat(1, s_v.Centroid);


%Recortamos imagen para eliminar fondo con sillas azules

im_marcador_azul = imagen(400:600,280:480,:);
%imshow(im_marcador_azul);

[BW_azul_1] = MARCHA_AZUL_HSV_2(im_marcador_azul);
% [BW_azul_1] = MARCHA_AZUL_LAB(imagen);
% [BW_azul_1] = mascara_azul_marcha(imagen);
%[BW_azul_1] = mascara_marcha_azulYY(imagen);
%imshow(BWr_83);
%En este caso no estamos detectando estructuras del fondo, pero si pasa
%tenemos que ajustar este número de píxeles
BW_azul_2 = bwareaopen(BW_azul_1,30);
%imshow(BWr2_83);
BW_azul_3 = imclose(BW_azul_2,se);

BW_azul_3_entera = imagen_negra;

BW_azul_3_entera(400:600,280:480,:) = BW_azul_3;

 s_a  = regionprops(BW_azul_3_entera, 'centroid');
          centroids(length(centroids)+1,:) = cat(1, s_a.Centroid);



[BW_amarilla_1] = MARCHA_HSV_AMARILLO_2(imagen);
% [BW_amarilla_1] = MARCHA_AMARILLO_LAB(imagen);
% [BW_amarilla_1] = mascara_marcha_amarillaYY(imagen);
%[BW_amarilla_1] = mascara_amarilla_marcha(imagen);
%imshow(BWr_83);
%En este caso no estamos detectando estructuras del fondo, pero si pasa
%tenemos que ajustar este número de píxeles
BW_amarilla_2 = bwareaopen(BW_amarilla_1,30);
%imshow(BWr2_83);
BW_amarilla_3 = imclose(BW_amarilla_2,se);

 s_am1  = regionprops(BW_amarilla_3, 'centroid');
          centroids(length(centroids)+1,:) = cat(1, s_am1.Centroid);



%Marcador amarillo hombro
im_marcador_amarillo_hombro = imagen(1:330,:,:);
% imshow(im_marcador_amarillo_hombro);
[BW_amarilla_arriba_1] = mascara_marcha_amarillo_arriba(im_marcador_amarillo_hombro);
% imshow(BW_amarilla_arriba_1);
% %En este caso no estamos detectando estructuras del fondo, pero si pasa
% %tenemos que ajustar este número de píxeles
BW_amarilla_arriba_2 = bwareaopen(BW_amarilla_arriba_1,30);
% %imshow(BWr2_83);
BW_amarilla_arriba_3 = imclose(BW_amarilla_arriba_2,se);
% imshow(BW_amarilla_arriba_3);


BW_amarilla_arriba_3_entera = imagen_negra;

BW_amarilla_arriba_3_entera(1:330,:,:) = BW_amarilla_arriba_3;

 s_am_2  = regionprops(BW_amarilla_arriba_3_entera, 'centroid');
          centroids(length(centroids)+1,:) = cat(1, s_am_2.Centroid);


%BW = BW_roja_3 | BW_verde_3 | BW_azul_3 | BW_amarilla_3 |BW_amarilla_arriba_3;
BW = BW_roja_3 | BW_verde_3 |  BW_amarilla_3;
BW(400:600,280:480,:) = BW_azul_3;
BW(1:330,:,:) = BW_amarilla_arriba_3;
%imshow (BW);
%BW_azul_3(400:600,280:480,:) 
%  s  = regionprops(BW, 'centroid');
%           centroids = cat(1, s.Centroid);
%           imshow(BW)
%           hold on
%           plot(centroids(:,1), centroids(:,2), 'b*')
%           hold off


cadera_rodilla = polyfit([centroids(3,1) centroids(2,1)], [centroids(3,2) centroids(2,2)],1);

rodilla_tobillo = polyfit([centroids(1,1) centroids(2,1)], [centroids(1,2) centroids(2,2)],1);

tobillo_pie = polyfit([centroids(1,1) centroids(4,1)],[centroids(1,2) centroids(4,2)],1);

cadera_tronco = polyfit([centroids(3,1) centroids(5,1)],[centroids(3,2) centroids(5,2)],1);


[angulo_cadera] = calcular_angulo(cadera_tronco, cadera_rodilla);

% if angulo_cadera> 135
% 
%  angulo_cadera = angulo_cadera-180;
% angulo_cadera = -angulo_cadera;
% end 
% %     angulo_cadera = -angulo_cadera;
% 
% 
% % angulo_cadera = -angulo_cadera;

[angulo_tobillo] = calcular_angulo(rodilla_tobillo, tobillo_pie);
% angulo_tobillo = angulo_tobillo - 90;
% if angulo_tobillo> 135
% 
%  angulo_tobillo = angulo_tobillo-180;
% 
% end

[angulo_rodilla] = calcular_angulo(cadera_rodilla, rodilla_tobillo);

% if angulo_rodilla> 135
% 
%  angulo_rodilla = angulo_rodilla-180;
% 
% end

end