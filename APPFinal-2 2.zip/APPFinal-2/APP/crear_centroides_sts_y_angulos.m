function [BW,BW_roja_3,BW_verde_3,BW_azul_3,BW_amarilla_3_entera,BW_amarilla_arriba_3_entera,centroids,angulo_cadera,angulo_rodilla,angulo_tobillo] = crear_centroides_sts_y_angulos(imagen)
centroids = 0;


%Marcador rojo
[BW_roja_1] = mascara_roja_sts_2(imagen);
%imshow(BWr_83);

BW_roja_2 = bwareaopen(BW_roja_1,30);

se = strel('disk',30);
BW_roja_3 = imclose(BW_roja_2,se);

s_r  = regionprops(BW_roja_3, 'centroid');
centroids = cat(1, s_r.Centroid);

imagen_negra = BW_roja_3;


%Crear imagen en negro
for i = 1:numel(imagen_negra)
    if imagen_negra(i) == 1
imagen_negra(i) = 0;

    end
end


%Marcador verde

[BW_verde_1] = mascara_verde_sts_2(imagen);
%imshow(BWr_83);

BW_verde_2 = bwareaopen(BW_verde_1,30);

BW_verde_3 = imclose(BW_verde_2,se);

 s_v  = regionprops(BW_verde_3, 'centroid');
          centroids(length(centroids),:) = cat(1, s_v.Centroid);


%Marcador azul

[BW_azul_1] = mascara_azul_sts2(imagen);
%imshow(BWr_83);

BW_azul_2 = bwareaopen(BW_azul_1,30);

BW_azul_3 = imclose(BW_azul_2,se);

 s_a  = regionprops(BW_azul_3, 'centroid');
          centroids(length(centroids)+1,:) = cat(1, s_a.Centroid);

          

%Marcador amarillo pie

im_marcador_amarillo_pie_sts = imagen(1129:1240,510:635,:);
%imshow(im_marcador_amarillo_pie_sts);

[BW_amarilla_1] = mascara_amarilla_sts_2(im_marcador_amarillo_pie_sts);
%imshow(BWr_83);

BW_amarilla_2 = bwareaopen(BW_amarilla_1,30);
%imshow(BWr2_83);

BW_amarilla_3 = imclose(BW_amarilla_2,se);

BW_amarilla_3_entera = imagen_negra;

BW_amarilla_3_entera(1129:1240,510:635,:) = BW_amarilla_3;

 s_am_1  = regionprops(BW_amarilla_3_entera, 'centroid');
          centroids(length(centroids)+1,:) = cat(1, s_am_1.Centroid);


%Marcador amarillo del hombro

im_marcador_amarillo_hombro_sts = imagen(1:420,:,:);
%imshow(im_marcador_amarillo_hombro_sts);

[BW_amarilla_arriba_1] = mascara_amarilla_sts_arriba_2(im_marcador_amarillo_hombro_sts);
%imshow(BWr_83);

BW_amarilla_arriba_2 = bwareaopen(BW_amarilla_arriba_1,30);
%imshow(BWr2_83);

BW_amarilla_arriba_3 = imclose(BW_amarilla_arriba_2,se);


BW_amarilla_arriba_3_entera = imagen_negra;


BW_amarilla_arriba_3_entera(1:420,:,:) = BW_amarilla_arriba_3;

 s_am_2  = regionprops(BW_amarilla_arriba_3_entera, 'centroid');
          centroids(length(centroids)+1,:) = cat(1, s_am_2.Centroid);




% BW = BW_roja_3 | BW_verde_3 | BW_azul_3 | BW_amarilla_3 |BW_amarilla_arriba_3;
BW = BW_roja_3 | BW_verde_3 | BW_azul_3 ;
BW(1:420,:,:) = BW_amarilla_arriba_3;
BW(1129:1240,510:635,:) = BW_amarilla_3;

%imshow (BW);

% s  = regionprops(BW, 'centroid');
       %   centroids = cat(1, s.Centroid);
%           centroids = cat(2, s.Centroid);
%           imshow(BW)
%           hold on
%           plot(centroids(:,1), centroids(:,2), 'b*')
%           hold off

cadera_rodilla = polyfit([centroids(3,1) centroids(2,1)], [centroids(3,2) centroids(2,2)],1);

rodilla_tobillo = polyfit([centroids(2,1) centroids(1,1)], [centroids(2,2) centroids(1,2)],1);

tobillo_pie = polyfit([centroids(1,1) centroids(4,1)],[centroids(1,2) centroids(4,2)],1);

cadera_tronco = polyfit([centroids(3,1) centroids(5,1)],[centroids(3,2) centroids(5,2)],1);


[angulo_cadera] = calcular_angulo(cadera_tronco,cadera_rodilla);

if angulo_cadera> 135

 angulo_cadera = angulo_cadera-180;
% else 
%     angulo_cadera = -angulo_cadera;
end


[angulo_tobillo] = calcular_angulo(rodilla_tobillo, tobillo_pie);


[angulo_rodilla] = calcular_angulo(cadera_rodilla, rodilla_tobillo); %-180

if angulo_rodilla> 135

 angulo_rodilla = angulo_rodilla-180;

 angulo_rodilla= -angulo_rodilla;

end


end