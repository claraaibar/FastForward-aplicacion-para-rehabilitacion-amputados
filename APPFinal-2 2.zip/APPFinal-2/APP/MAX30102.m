
clear all
clc
b = [];
tamanob = [3,length(i)];
a = [];
tamano = [3,length(i)];

%Initialize serial 
delete(instrfind({'Port'},{'COM6'}));
arduino2=serial('COM6','BaudRate',115200);

delete(instrfind({'Port'},{'COM3'}));
arduino=serial('COM3','BaudRate',115200);
 
fopen(arduino2);
fopen(arduino);

tic;
%	[a, count, m]=fscanf(arduino, "%f");
for i = 1:14

   a{i}= fscanf(arduino, "%f",tamano);

   a1 = cell2mat(a);

   b{i}= fscanf(arduino2, "%f",tamanob);

   b1 = cell2mat(b);
   
end
fclose(arduino2);
fclose(arduino);
tiempo = toc;
filas = round(length(a1)/3)*3;
if filas > length(a1)
    filas = filas -3;
    a1(:,filas+1:end)=[];
end
a2= reshape(a1,3,[]);


ejex_femur = linspace(0,1,length(a2(1,:))); 
figure
plot(ejex_femur,a2(1,:));


ejex = linspace(0,1,length(b1)); 
figure
plot(ejex,b1);