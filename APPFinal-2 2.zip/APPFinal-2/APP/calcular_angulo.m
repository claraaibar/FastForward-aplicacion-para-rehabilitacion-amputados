function [angle] = calcular_angulo(recta1, recta2, BW)


vect1 = [1 recta1(1)]; % Create a vector based on the line equation
vect2 = [1 recta2(1)];
dp = dot(vect1, vect2);


length1 = sqrt(sum(vect1.^2));
length2 = sqrt(sum(vect2.^2));

angle = 180-acos(dp/(length1*length2))*180/pi;angle

intersection = [1 ,-recta1(1); 1, -recta2(1)] \ [recta1(2); recta2(2)];
inter_x = intersection(2);
inter_y = intersection(1);
% 
% imshow(BW)
% hold on
% plot(inter_x,inter_y,"rx","LineWidth",2);

end