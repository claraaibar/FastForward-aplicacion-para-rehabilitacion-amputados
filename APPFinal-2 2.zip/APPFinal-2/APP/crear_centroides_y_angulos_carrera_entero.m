function [BW,BW_roja_3,BW_verde_3,BW_azul_3_entera,BW_amarilla_3_entera,BW_amarilla_arr_3_entera,centroids,angulo_cadera,angulo_tobillo,angulo_rodilla] = crear_centroides_y_angulos_carrera_entero(imagen)

[BW_roja_1] = mascara_roja_carrera_entero(imagen);
%imshow(BWr_83);
%En este caso no estamos detectando estructuras del fondo, pero si pasa
%tenemos que ajustar este número de píxeles
BW_roja_2 = bwareaopen(BW_roja_1,30);
%imshow(BWr2_83);
se = strel('disk',30);
BW_roja_3 = imclose(BW_roja_2,se);

 s_r  = regionprops(BW_roja_3, 'centroid');
 centroids = cat(1, s_r.Centroid);

 imagen_negra = BW_roja_3;
%Crear imagen en negro
for i = 1:numel(imagen_negra)
    if imagen_negra(i) == 1
imagen_negra(i) = 0;

    end
end


[BW_verde_1] = mascara_verde_carrera_entero(imagen);
%imshow(BWr_83);
%En este caso no estamos detectando estructuras del fondo, pero si pasa
%tenemos que ajustar este número de píxeles
BW_verde_2 = bwareaopen(BW_verde_1,30);
%imshow(BWr2_83);
BW_verde_3 = imclose(BW_verde_2,se);

 s_v  = regionprops(BW_verde_3, 'centroid');

 if length(s_v) == 0

[BW_verde_1] = mascara_verde_carrera_entero_2(imagen);
%imshow(BWr_83);
%En este caso no estamos detectando estructuras del fondo, pero si pasa
%tenemos que ajustar este número de píxeles
BW_verde_2 = bwareaopen(BW_verde_1,30);
%imshow(BWr2_83);
BW_verde_3 = imclose(BW_verde_2,se);
s_v  = regionprops(BW_verde_3, 'centroid');

 end
          centroids(length(centroids),:) = cat(1, s_v.Centroid);


%Recortamos imagen para eliminar fondo con sillas azules
% 
im_marcador_azul = imagen(380:700,90:455,:);
%imshow(im_marcador_azul);

[BW_azul_1] = mascara_azul_carrera_entero(im_marcador_azul);
%imshow(BWr_83);
%En este caso no estamos detectando estructuras del fondo, pero si pasa
%tenemos que ajustar este número de píxeles
BW_azul_2 = bwareaopen(BW_azul_1,30);
%imshow(BWr2_83);
BW_azul_3 = imclose(BW_azul_2,se);

BW_azul_3_entera = imagen_negra;

BW_azul_3_entera(380:700,90:455,:) = BW_azul_3;

 s_a  = regionprops(BW_azul_3_entera, 'centroid');
          centroids(length(centroids)+1,:) = cat(1, s_a.Centroid);



%Marcador del pie
im_marcador_pie = imagen(800:1280,:,:);
% imshow(BW_amarilla_1);

%A ver con esta máscara
[BW_amarilla_1] = probar_amarillo_jeje(im_marcador_pie);
% [BW_amarilla_1] = mascara_amarilla_carrera_entero(im_marcador_pie);
% imshow(BW_amarilla_1);
%En este caso no estamos detectando estructuras del fondo, pero si pasa
%tenemos que ajustar este número de píxeles
BW_amarilla_2 = bwareaopen(BW_amarilla_1,30);
%imshow(BWr2_83);
BW_amarilla_3 = imclose(BW_amarilla_2,se);

BW_amarilla_3_entera = imagen_negra;

BW_amarilla_3_entera(800:1280,:,:) = BW_amarilla_3;

 s_am_1  = regionprops(BW_amarilla_3_entera, 'centroid');
          centroids(length(centroids)+1,:) = cat(1, s_am_1.Centroid);



%Marcador del hombro
im_marcador_amarillo_hombro = imagen(1:330,:,:);
% imshow(im_marcador_amarillo_hombro);

[BW_amarilla_arr_1] = mascara_amarilla_hombro_carrera_entera(im_marcador_amarillo_hombro);
%imshow(BW_amarilla_arr_1);
%En este caso no estamos detectando estructuras del fondo, pero si pasa
%tenemos que ajustar este número de píxeles
BW_amarilla_arr_2 = bwareaopen(BW_amarilla_arr_1,30);
%imshow(BWr2_83);
BW_amarilla_arr_3 = imclose(BW_amarilla_arr_2,se);
% 
% imshow(BW_amarilla_arr_3_entera);

BW_amarilla_arr_3_entera = imagen_negra;

BW_amarilla_arr_3_entera(1:330,:,:) = BW_amarilla_arr_3;

 s_am_2  = regionprops(BW_amarilla_arr_3_entera, 'centroid');
          centroids(length(centroids)+1,:) = cat(1, s_am_2.Centroid);





%BW = BW_roja_3 | BW_verde_3 | BW_azul_3 | BW_amarilla_3 |BW_amarilla_arriba_3;
BW = BW_roja_3 | BW_verde_3 | BW_amarilla_arr_3_entera | BW_amarilla_3_entera | BW_azul_3_entera;
% BW(380:700,90:455,:) = BW_azul_3;
% BW(1:330,:,:) = BW_amarilla_arr_3;
% BW(800:1280,:,:)= BW_amarilla_3;
%imshow (BW);

 %s  = regionprops(BW, 'centroid');
          %centroids = cat(1, s.Centroid);
%           imshow(BW)
%           hold on
%           plot(centroids(:,1), centroids(:,2), 'b*')
%           hold off

cadera_rodilla = polyfit([centroids(3,1) centroids(2,1)], [centroids(3,2) centroids(2,2)],1);

rodilla_tobillo = polyfit([centroids(1,1) centroids(2,1)], [centroids(1,2) centroids(2,2)],1);

tobillo_pie = polyfit([centroids(1,1) centroids(4,1)],[centroids(1,2) centroids(4,2)],1);

cadera_tronco = polyfit([centroids(3,1) centroids(5,1)],[centroids(3,2) centroids(5,2)],1);


[angulo_cadera] = calcular_angulo(cadera_tronco, cadera_rodilla);

[angulo_tobillo] = calcular_angulo(rodilla_tobillo, tobillo_pie);

[angulo_rodilla] = calcular_angulo(cadera_rodilla, rodilla_tobillo);

end